<?php

$servername='localhost';
$username='root';
$password='nsl';
$dbname='nsl';


$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn)
{
echo "not connected";
}
else
{
echo "<form action=teamsinleague.php method=POST>
<input type=submit value=teams formaction=teamsinleague.php></form>";

echo "<br>";

echo "<form action=players.php method=POST>
<input type=submit value=players-in-each-team></form>";
echo "<br>";

echo "<form action=result.php method=POST>
<input type=submit value=result></form>";
echo "<br>";

echo "<form action=point-table.php method=POST>
<input type=submit value=pointstable></form>";
echo "<br>";

echo "<form action=playerranking.php method=POST>
<input type=submit value=view-player-ranking></form>";
echo "<br>";
}
?>

