-- MySQL dump 10.13  Distrib 5.5.44, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: nsl
-- ------------------------------------------------------
-- Server version	5.5.44-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `goals`
--

DROP TABLE IF EXISTS `goals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `goals` (
  `guestid` varchar(10) NOT NULL,
  `hostid` varchar(10) NOT NULL,
  `pid` varchar(10) NOT NULL,
  `numgoals` int(11) NOT NULL,
  `yellowcard` varchar(20) NOT NULL,
  `redcard` varchar(20) NOT NULL,
  PRIMARY KEY (`guestid`,`hostid`,`pid`),
  KEY `hostid` (`hostid`),
  KEY `pid` (`pid`),
  CONSTRAINT `goals_ibfk_6` FOREIGN KEY (`pid`) REFERENCES `player` (`pid`),
  CONSTRAINT `goals_ibfk_1` FOREIGN KEY (`guestid`) REFERENCES `team` (`tid`),
  CONSTRAINT `goals_ibfk_2` FOREIGN KEY (`hostid`) REFERENCES `team` (`tid`),
  CONSTRAINT `goals_ibfk_3` FOREIGN KEY (`pid`) REFERENCES `player` (`pid`),
  CONSTRAINT `goals_ibfk_4` FOREIGN KEY (`guestid`) REFERENCES `team` (`tid`),
  CONSTRAINT `goals_ibfk_5` FOREIGN KEY (`hostid`) REFERENCES `team` (`tid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goals`
--

LOCK TABLES `goals` WRITE;
/*!40000 ALTER TABLE `goals` DISABLE KEYS */;
INSERT INTO `goals` VALUES ('t1','t2','p1',1,'no','no');
/*!40000 ALTER TABLE `goals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matches`
--

DROP TABLE IF EXISTS `matches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matches` (
  `guestid` varchar(10) NOT NULL,
  `hostid` varchar(10) NOT NULL,
  `location` varchar(30) NOT NULL,
  `matchdate` int(11) NOT NULL,
  `winteam` varchar(20) DEFAULT NULL,
  `result` int(11) NOT NULL,
  `mainref` varchar(20) NOT NULL,
  `asstref1` varchar(20) NOT NULL,
  `asstref2` varchar(20) NOT NULL,
  `wingoals` int(11) NOT NULL,
  `lossgoals` int(11) NOT NULL,
  PRIMARY KEY (`guestid`,`hostid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matches`
--

LOCK TABLES `matches` WRITE;
/*!40000 ALTER TABLE `matches` DISABLE KEYS */;
INSERT INTO `matches` VALUES ('t1','t2','kochi',2015,'t1',2,'r1','r2','r3',3,2);
/*!40000 ALTER TABLE `matches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player`
--

DROP TABLE IF EXISTS `player`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player` (
  `pid` varchar(10) NOT NULL,
  `pname` varchar(20) NOT NULL,
  `dob` date NOT NULL,
  `startyear` int(11) NOT NULL,
  `shirtnumber` int(11) NOT NULL,
  `tid` varchar(10) NOT NULL,
  PRIMARY KEY (`pid`),
  KEY `tid` (`tid`),
  CONSTRAINT `player_ibfk_1` FOREIGN KEY (`tid`) REFERENCES `team` (`tid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player`
--

LOCK TABLES `player` WRITE;
/*!40000 ALTER TABLE `player` DISABLE KEYS */;
INSERT INTO `player` VALUES ('p1','piyush','1989-10-12',2007,8,'t1'),('p10','vineet','1990-11-21',2004,67,'t2'),('p11','karthik','1986-01-02',1995,89,'t3'),('p12','surya','1988-05-22',2000,8,'t3'),('p13','kalyan','1990-12-12',2010,56,'t3'),('p14','kiran','1998-04-20',2000,58,'t3'),('p15','vinay','1990-11-21',2004,7,'t3'),('p16','ramesh','1986-01-02',1995,85,'t4'),('p17','rayudu','1988-05-22',2000,38,'t4'),('p18','raja','1990-12-12',2010,83,'t4'),('p19','rambabu','1998-04-20',2000,88,'t4'),('p2','patel','1990-08-12',2007,7,'t1'),('p20','vivek','1990-11-21',2004,7,'t4'),('p21','vishnu','1986-01-02',1995,45,'t5'),('p22','manpreeth','1988-05-22',2000,68,'t5'),('p23','nimesh','1990-12-12',2010,89,'t5'),('p24','kousthub','1998-04-20',2000,1,'t4'),('p25','aditya','1990-11-21',2004,99,'t5'),('p26','amar','1986-01-02',1994,85,'t6'),('p27','nihal','1988-05-22',2010,38,'t6'),('p28','rahim','1990-12-12',2000,83,'t6'),('p29','ram','1998-04-20',2006,88,'t6'),('p3','sunil','1987-01-12',2004,3,'t1'),('p30','vishakh','1990-11-21',2004,7,'t6'),('p4','pankaj','1991-12-12',2009,99,'t1'),('p5','prabhav','1986-11-12',2000,1,'t1'),('p6','kamran','1986-01-02',1995,8,'t2'),('p7','arjun','1988-05-22',2000,18,'t2'),('p8','amar','1990-12-12',2010,85,'t2'),('p9','kranthi','1998-04-20',2000,58,'t2');
/*!40000 ALTER TABLE `player` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refere`
--

DROP TABLE IF EXISTS `refere`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refere` (
  `rid` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `dob` date NOT NULL,
  `experience` int(11) NOT NULL,
  PRIMARY KEY (`rid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refere`
--

LOCK TABLES `refere` WRITE;
/*!40000 ALTER TABLE `refere` DISABLE KEYS */;
/*!40000 ALTER TABLE `refere` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `team` (
  `tid` varchar(10) NOT NULL,
  `tname` varchar(25) NOT NULL,
  `captain` varchar(30) NOT NULL,
  `stadium` varchar(20) NOT NULL,
  `city` varchar(30) NOT NULL,
  PRIMARY KEY (`tid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team`
--

LOCK TABLES `team` WRITE;
/*!40000 ALTER TABLE `team` DISABLE KEYS */;
INSERT INTO `team` VALUES ('t1','deccan chargers','sunil','gacchi','hyderabad'),('t2','tuskers','amar','kochi','kochin'),('t3','super kings','karthik','chennai','chennai'),('t4','mumbai indians','ramesh','ambedkar','mumbai'),('t5','knight riders','vishnu','shiva','kolkata'),('t6','royal challengers','amar','kannadi','banglore');
/*!40000 ALTER TABLE `team` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-11-10 17:02:24
