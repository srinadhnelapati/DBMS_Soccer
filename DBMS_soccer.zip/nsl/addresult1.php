
<?php
$servername='localhost';
$username='root';
$password='nsl';
$dbname='nsl';


$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn)
{
echo "not connected";
}
else
{
//echo "connected";
$var1=$_POST["gid"];
$var2=$_POST["hid"];
$var3=$_POST["loc"];
$var4=$_POST["dt"];
$var5=$_POST["ref1"];
$var6=$_POST["ref2"];
$var7=$_POST["ref3"];
$var8=$_POST["win"];
$var9=$_POST["result"];
$var10=$_POST["win-goals"];
$var11=$_POST["loss-goals"];
$sql="INSERT INTO matches VALUES('$var1','$var2','$var3','$var4','$var8','$var9','$var5','$var6','$var7',$var10,$var11)";

$result=mysqli_query($conn,$sql);

if($result)
{
echo "added successfully";
}
else
{
echo "error";
}
}

?>
