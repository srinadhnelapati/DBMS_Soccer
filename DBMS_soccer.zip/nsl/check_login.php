<?php

$servername='localhost';
$username='root';
$password='nsl';
$dbname='nsl';


$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn)
{
echo "not connected";
}
else
{
$var1=$_POST["username"];
$var2=$_POST["password"];
if($var1=='admin')
{
if($var2=='shift724')
{
echo "WELCOME Admin";
echo "<form action=update.php method=POST>
<input type=submit value=updateresult></form>";
echo "<br>";
echo "<form action=addresult.php method=POST>
<input type=submit value=addnewresult></form>";

echo "<p text-align=center ><form action=index.php method=POST>
<input type=submit value=logout></form></p>";
}
else
{
echo "incorrect username or password";
echo "<form action=index.php method=POST>
<input type=submit value=retry-login></form>";
}
}
else
{
echo "incorrect username or password";
echo "<form action=index.php method=POST>
<input type=submit value=retry-login></form>";
}
}
?>

