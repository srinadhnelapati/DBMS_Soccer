<?php

$servername='localhost';
$username='root';
$password='nsl';
$dbname='nsl';


$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn)
{
echo "not connected";
}
else
{

$sql="SELECT * FROM team";
$result=mysqli_query($conn,$sql);
if(!$result)
{
echo "error in getting results";
exit();
}
else
{

$count=mysqli_num_rows($result);

//echo $count;

if($count>0)
{


echo "<table>";

echo "<th colspan=1>"."TID"."</th>"."<th colspan=1>"."NAME"."</th>"."<th colspan=1>"."CAPTAIN"."</th>"."<th colspan=1>"."STADIUM"."</th>"."<th colspan=1>"."CITY"."</th>";
while($row=mysqli_fetch_assoc($result))
{
echo "<tr>"."<td>".$row["tid"]."</td>"."<td>".$row["tname"]."</td>"."<td>".$row["captain"]."</td>"."<td>".$row["stadium"]."</td>"."<td>".$row["city"]."</td>"."</tr>";
}
echo "</table>";
}
else
{
echo "no teams are registered into this league";
exit();
}
}
}
?>
