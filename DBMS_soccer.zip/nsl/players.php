<?php

$servername='localhost';
$username='root';
$password='nsl';
$dbname='nsl';


$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn)
{
echo "not connected";
}
else
{
$sql="SELECT * FROM player";
$result=mysqli_query($conn,$sql);
if(!$result)
{
echo "error";
exit();
}
else
{
$count=mysqli_num_rows($result);
if($count>0)
{
echo "<table>";

echo "<th colspan=1>"."PID"."</th>"."<th colspan=1>"."NAME"."</th>"."<th colspan=1>"."DOB"."</th>"."<th colspan=1>"."START-YEAR"."</th>"."<th colspan=1>"."SHIRT-NUMBER"."</th>"."<th colspan=1>"."TID"."</th>";
$cou=0;
while($row=mysqli_fetch_assoc($result))
{
if($cou==0)
{
//echo $row["tid"];
}
echo "<tr>"."<td>".$row["pid"]."</td>"."<td>".$row["pname"]."</td>"."<td>".$row["dob"]."</td>"."<td>".$row["startyear"]."</td>"."<td>".$row["shirtnumber"]."</td>"."<td>".$row["tid"]."</td>"."</tr>";
$cou=$cou+1;
if($cou==5)
{
$cou==0;
}
}
echo "</table>";
}
}
}
?> 
<html>
<head>
<style>

</style>

