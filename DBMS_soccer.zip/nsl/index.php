<html>
<head>
<style>
body{
background-color:crimson;
}
</style>
</head>
<body>
<form action="check_login.php" method="POST">
<p>Username:</p>
<input type="text" name="username" placeholder="username">
<p>Password:</p>
<input type="password" name="password" placeholder="password"><br>
<input type="submit" value="login">

</form>

<br>

<form action="guest.php" method="POST">
<input type="submit" value="login-as-guest"></form>

</body>
</html>
