
<html>
<head>
</head>
<body>


<form action="addplayer1.php" method="POST">
<fieldset>
guest-team-id:<br>
<input type="text" name="gid" placeholder="guest-team-id" required>
<br>
host-team-id:<br>
<input type="text" name="hid" placeholder="host-team-id" required>
<br>
player-id:<br>
<input type="text" name="pid" placeholder="player-id" required>
<br>
number-of-goals:<br>
<input type="text" name="goal" placeholder="number-of-goals" required><br>
yellowcard:<br>
<input type="text" name="yellow" placeholder="yes/no" required><br>
redcard:<br>
<input type="text" name="red" placeholder="yes/no" required><br>
<br>
<input type="submit" value="add-player">
</fieldset>
</form>
</body>
</html>
