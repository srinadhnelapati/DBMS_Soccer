<html>
<head>
</head>
<body>


<form action="add.php" method="POST">
<input type="submit" value="add-team" formaction="add.php">
<input type="submit" value="add-players" formaction="addplayer.php">
</form>
</body>

</html>

