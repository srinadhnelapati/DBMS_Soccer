<?php
$servername='localhost';
$username='root';
$password='nsl';
$dbname='nsl';


$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn)
{
echo "not connected";
}
else
{
//echo "connected";
}


?>

<html>
<head>
</head>
<body>


<form action="addresult1.php" method="POST">
<fieldset>
guest-team-id:<br>
<input type="text" name="gid" placeholder="guest-team-id" required>
<br>
host-team-id:<br>
<input type="text" name="hid" placeholder="host-team-id" required>
<br>
venue:<br>
<input type="text" name="loc" placeholder="venue" required>
<br>
match-date:<br>
<input type="text" name="dt" placeholder="match-date" required>
<br>
refid:<br>
<input type="text" name="ref1" placeholder="refid" required>
<br>
asst1.refid:<br>
<input type="text" name="ref2" placeholder="asst1.refid" required>
<br>
asst2.refid:<br>
<input type="text" name="ref3" placeholder="asst2.refid" required>
<br>
winteam:<br>
<input type="text" name="win" placeholder="winteam" required>
<br>
result:<br>
<input type="text" name="result" placeholder="result" required>
</fieldset>


<fieldset>
<br>
winteam-goals:<br>
<input type="text" name="win-goals" placeholder="winteam-goals" required>
<br>
loss-team-id:<br>
<input type="text" name="loss-goals" placeholder="loss-team-id" required>
<br>
</fieldset>
<input type="submit" value="add">

</form>




</body>
</html>
