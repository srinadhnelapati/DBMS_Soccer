<?php
$servername='localhost';
$username='root';
$password='nsl';
$dbname='nsl';


$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn)
{
echo "not connected";
}
else
{
$var1=$_POST["gid"];
$var2=$_POST["hid"];
$var3=$_POST["pid"];
$var4=$_POST["goal"];
$var5=$_POST["yellow"];
$var6=$_POST["red"];
$sql="INSERT INTO goals VALUES('$var1','$var2','$var3',$var4,'$var5','$var6')";
$result=mysqli_query($conn,$sql);
if($result)
{
echo "added successfully";
}
else
{
echo "error in adding";
}
}
?>
